
export type Point = { x: number; y: number };

export type TetrominoType = 'I' | 'J' | 'L' | 'O' | 'S' | 'T' | 'Z';

export interface Tetromino {
  shape: number[][];
  color: string;
  glowColor: string;
  type: TetrominoType;
}

export const TETROMINOES: Record<TetrominoType, Tetromino> = {
  I: {
    shape: [
      [0, 0, 0, 0],
      [1, 1, 1, 1],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ],
    color: '#00f2ff', // Neon Cyan
    glowColor: 'rgba(0, 242, 255, 0.8)',
    type: 'I',
  },
  J: {
    shape: [
      [1, 0, 0],
      [1, 1, 1],
      [0, 0, 0],
    ],
    color: '#3d5afe', // Neon Blue
    glowColor: 'rgba(61, 90, 254, 0.8)',
    type: 'J',
  },
  L: {
    shape: [
      [0, 0, 1],
      [1, 1, 1],
      [0, 0, 0],
    ],
    color: '#ff9100', // Neon Orange
    glowColor: 'rgba(255, 145, 0, 0.8)',
    type: 'L',
  },
  O: {
    shape: [
      [1, 1],
      [1, 1],
    ],
    color: '#ffea00', // Neon Yellow
    glowColor: 'rgba(255, 234, 0, 0.8)',
    type: 'O',
  },
  S: {
    shape: [
      [0, 1, 1],
      [1, 1, 0],
      [0, 0, 0],
    ],
    color: '#00e676', // Neon Green
    glowColor: 'rgba(0, 230, 118, 0.8)',
    type: 'S',
  },
  T: {
    shape: [
      [0, 1, 0],
      [1, 1, 1],
      [0, 0, 0],
    ],
    color: '#d500f9', // Neon Purple
    glowColor: 'rgba(213, 0, 249, 0.8)',
    type: 'T',
  },
  Z: {
    shape: [
      [1, 1, 0],
      [0, 1, 1],
      [0, 0, 0],
    ],
    color: '#ff1744', // Neon Red
    glowColor: 'rgba(255, 23, 68, 0.8)',
    type: 'Z',
  },
};

export const COLS = 10;
export const ROWS = 20;
export const BLOCK_SIZE = 30;
