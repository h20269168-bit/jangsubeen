import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useTetris } from '../hooks/useTetris';
import { COLS, ROWS, BLOCK_SIZE, TETROMINOES } from '../constants';
import { Trophy, Play, Pause, RotateCcw, Diamond as DiamondIcon } from 'lucide-react';

export const TetrisGame: React.FC = () => {
  const {
    grid,
    activePiece,
    score,
    level,
    gameOver,
    diamonds,
    isPaused,
    setIsPaused,
    move,
    rotate,
    resetGame,
  } = useTetris();

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Draw diamonds on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    diamonds.forEach((d) => {
      ctx.save();
      ctx.translate(d.x, d.y);
      ctx.rotate((d.rotation * Math.PI) / 180);
      ctx.scale(d.scale, d.scale);
      ctx.globalAlpha = d.opacity;

      // Draw a diamond shape
      ctx.beginPath();
      ctx.moveTo(0, -10);
      ctx.lineTo(10, 0);
      ctx.lineTo(0, 10);
      ctx.lineTo(-10, 0);
      ctx.closePath();

      // Neon Cyan Glow
      ctx.shadowBlur = 15;
      ctx.shadowColor = '#00f2ff';
      ctx.fillStyle = '#00f2ff';
      ctx.fill();

      // Inner white part
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.moveTo(0, -5);
      ctx.lineTo(5, 0);
      ctx.lineTo(0, 5);
      ctx.lineTo(-5, 0);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    });
  }, [diamonds]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameOver) return;

      switch (e.key) {
        case 'ArrowLeft':
          move({ x: -1, y: 0 });
          break;
        case 'ArrowRight':
          move({ x: 1, y: 0 });
          break;
        case 'ArrowDown':
          move({ x: 0, y: 1 });
          break;
        case 'ArrowUp':
          rotate();
          break;
        case ' ':
          // Hard drop could be added here
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [move, rotate, gameOver]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white font-sans overflow-hidden p-4">
      {/* Background Glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-900/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-900/20 rounded-full blur-[120px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 flex flex-col md:flex-row gap-8 items-start"
      >
        {/* Game Board */}
        <div className="relative p-2 bg-gray-900/50 border-2 border-gray-800 rounded-xl shadow-[0_0_50px_rgba(0,0,0,0.5)] backdrop-blur-sm">
          <div
            className="relative overflow-hidden bg-black/80"
            style={{
              width: COLS * BLOCK_SIZE,
              height: ROWS * BLOCK_SIZE,
            }}
          >
            {/* Grid Lines */}
            <div className="absolute inset-0 grid grid-cols-10 grid-rows-20 pointer-events-none opacity-10">
              {Array.from({ length: COLS * ROWS }).map((_, i) => (
                <div key={i} className="border-[0.5px] border-white/20" />
              ))}
            </div>

            {/* Static Grid Blocks */}
            {grid.map((row, y) =>
              row.map((color, x) =>
                color ? (
                  <div
                    key={`${x}-${y}`}
                    className="absolute border border-black/20 rounded-sm"
                    style={{
                      width: BLOCK_SIZE,
                      height: BLOCK_SIZE,
                      left: x * BLOCK_SIZE,
                      top: y * BLOCK_SIZE,
                      backgroundColor: color,
                      boxShadow: `0 0 15px ${color}`,
                    }}
                  />
                ) : null
              )
            )}

            {/* Active Piece */}
            {activePiece &&
              activePiece.shape.map((row, y) =>
                row.map((value, x) =>
                  value !== 0 ? (
                    <motion.div
                      key={`active-${x}-${y}`}
                      className="absolute border border-black/20 rounded-sm"
                      style={{
                        width: BLOCK_SIZE,
                        height: BLOCK_SIZE,
                        left: (activePiece.pos.x + x) * BLOCK_SIZE,
                        top: (activePiece.pos.y + y) * BLOCK_SIZE,
                        backgroundColor: TETROMINOES[activePiece.type].color,
                        boxShadow: `0 0 20px ${TETROMINOES[activePiece.type].color}`,
                      }}
                    />
                  ) : null
                )
              )}

            {/* Diamond Canvas Overlay */}
            <canvas
              ref={canvasRef}
              width={COLS * BLOCK_SIZE}
              height={ROWS * BLOCK_SIZE}
              className="absolute inset-0 pointer-events-none"
            />

            {/* Game Over Overlay */}
            <AnimatePresence>
              {gameOver && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md z-50"
                >
                  <h2 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-purple-600 mb-4 uppercase tracking-tighter">
                    Game Over
                  </h2>
                  <p className="text-xl mb-6 font-mono">Score: {score}</p>
                  <button
                    onClick={resetGame}
                    className="px-8 py-3 bg-white text-black font-bold rounded-full hover:scale-105 transition-transform flex items-center gap-2"
                  >
                    <RotateCcw size={20} />
                    Try Again
                  </button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Pause Overlay */}
            <AnimatePresence>
              {isPaused && !gameOver && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm z-40"
                >
                  <h2 className="text-3xl font-bold mb-6 uppercase tracking-widest">Paused</h2>
                  <button
                    onClick={() => setIsPaused(false)}
                    className="p-4 bg-white/10 hover:bg-white/20 rounded-full transition-colors"
                  >
                    <Play size={40} fill="white" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="flex flex-col gap-6 min-w-[200px]">
          <div className="p-6 bg-gray-900/50 border border-gray-800 rounded-2xl backdrop-blur-md">
            <div className="flex items-center gap-2 text-gray-400 mb-2 uppercase text-xs font-bold tracking-widest">
              <Trophy size={14} />
              Score
            </div>
            <div className="text-4xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
              {score.toLocaleString()}
            </div>
          </div>

          <div className="p-6 bg-gray-900/50 border border-gray-800 rounded-2xl backdrop-blur-md">
            <div className="flex items-center gap-2 text-gray-400 mb-2 uppercase text-xs font-bold tracking-widest">
              <Play size={14} />
              Level
            </div>
            <div className="text-4xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
              {level}
            </div>
          </div>

          <div className="p-6 bg-gray-900/50 border border-gray-800 rounded-2xl backdrop-blur-md">
            <div className="flex items-center gap-2 text-gray-400 mb-2 uppercase text-xs font-bold tracking-widest">
              <DiamondIcon size={14} />
              Diamonds
            </div>
            <div className="text-4xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
              {Math.floor(score / 100)}
            </div>
          </div>

          <div className="flex gap-4 mt-auto">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="flex-1 p-4 bg-gray-800 hover:bg-gray-700 rounded-xl transition-colors flex items-center justify-center"
            >
              {isPaused ? <Play size={24} /> : <Pause size={24} />}
            </button>
            <button
              onClick={resetGame}
              className="flex-1 p-4 bg-gray-800 hover:bg-gray-700 rounded-xl transition-colors flex items-center justify-center"
            >
              <RotateCcw size={24} />
            </button>
          </div>
        </div>
      </motion.div>

      {/* Controls Hint */}
      <div className="mt-12 text-gray-500 text-sm font-medium flex gap-8 uppercase tracking-widest">
        <div className="flex items-center gap-2">
          <span className="px-2 py-1 bg-gray-800 rounded text-xs">↑</span> Rotate
        </div>
        <div className="flex items-center gap-2">
          <span className="px-2 py-1 bg-gray-800 rounded text-xs">← →</span> Move
        </div>
        <div className="flex items-center gap-2">
          <span className="px-2 py-1 bg-gray-800 rounded text-xs">↓</span> Drop
        </div>
      </div>
    </div>
  );
};
