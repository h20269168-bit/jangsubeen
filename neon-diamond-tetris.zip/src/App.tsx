/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TetrisGame } from './components/TetrisGame';

export default function App() {
  return (
    <div className="min-h-screen bg-black overflow-hidden">
      <TetrisGame />
    </div>
  );
}
