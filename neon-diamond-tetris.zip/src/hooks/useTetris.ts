import { useState, useCallback, useEffect, useRef } from 'react';
import { COLS, ROWS, TETROMINOES, TetrominoType, Point } from '../constants';

export interface Diamond {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  rotation: number;
  scale: number;
  opacity: number;
}

export const useTetris = () => {
  const [grid, setGrid] = useState<(string | null)[][]>(
    Array.from({ length: ROWS }, () => Array(COLS).fill(null))
  );
  const [activePiece, setActivePiece] = useState<{
    type: TetrominoType;
    pos: Point;
    shape: number[][];
  } | null>(null);
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [gameOver, setGameOver] = useState(false);
  const [diamonds, setDiamonds] = useState<Diamond[]>([]);
  const [isPaused, setIsPaused] = useState(false);

  const gridRef = useRef(grid);
  gridRef.current = grid;

  const spawnPiece = useCallback(() => {
    const types: TetrominoType[] = ['I', 'J', 'L', 'O', 'S', 'T', 'Z'];
    const type = types[Math.floor(Math.random() * types.length)];
    const piece = TETROMINOES[type];
    const pos = { x: Math.floor(COLS / 2) - Math.floor(piece.shape[0].length / 2), y: 0 };

    if (checkCollision(pos, piece.shape)) {
      setGameOver(true);
      return;
    }

    setActivePiece({ type, pos, shape: piece.shape });
  }, []);

  const checkCollision = (pos: Point, shape: number[][], currentGrid = gridRef.current) => {
    for (let y = 0; y < shape.length; y++) {
      for (let x = 0; x < shape[y].length; x++) {
        if (shape[y][x] !== 0) {
          const newX = pos.x + x;
          const newY = pos.y + y;

          if (
            newX < 0 ||
            newX >= COLS ||
            newY >= ROWS ||
            (newY >= 0 && currentGrid[newY][newX] !== null)
          ) {
            return true;
          }
        }
      }
    }
    return false;
  };

  const rotate = useCallback(() => {
    if (!activePiece || gameOver || isPaused) return;

    const newShape = activePiece.shape[0].map((_, i) =>
      activePiece.shape.map((row) => row[i]).reverse()
    );

    if (!checkCollision(activePiece.pos, newShape)) {
      setActivePiece((prev) => (prev ? { ...prev, shape: newShape } : null));
    }
  }, [activePiece, gameOver, isPaused]);

  const move = useCallback(
    (dir: { x: number; y: number }) => {
      if (!activePiece || gameOver || isPaused) return false;

      const newPos = { x: activePiece.pos.x + dir.x, y: activePiece.pos.y + dir.y };

      if (!checkCollision(newPos, activePiece.shape)) {
        setActivePiece((prev) => (prev ? { ...prev, pos: newPos } : null));
        return true;
      }

      if (dir.y > 0) {
        lockPiece();
      }
      return false;
    },
    [activePiece, gameOver, isPaused]
  );

  const lockPiece = useCallback(() => {
    if (!activePiece) return;

    const newGrid = [...gridRef.current.map((row) => [...row])];
    activePiece.shape.forEach((row, y) => {
      row.forEach((value, x) => {
        if (value !== 0) {
          const gridY = activePiece.pos.y + y;
          const gridX = activePiece.pos.x + x;
          if (gridY >= 0) {
            newGrid[gridY][gridX] = TETROMINOES[activePiece.type].color;
          }
        }
      });
    });

    // Check for full lines
    let linesCleared = 0;
    const finalGrid = newGrid.filter((row, rowIndex) => {
      const isFull = row.every((cell) => cell !== null);
      if (isFull) {
        linesCleared++;
        // Spawn diamonds at the cleared line position
        spawnDiamonds(rowIndex);
      }
      return !isFull;
    });

    while (finalGrid.length < ROWS) {
      finalGrid.unshift(Array(COLS).fill(null));
    }

    setGrid(finalGrid);
    if (linesCleared > 0) {
      setScore((prev) => prev + linesCleared * 100 * level);
      if (score > level * 1000) {
        setLevel((prev) => prev + 1);
      }
    }

    setActivePiece(null);
    spawnPiece();
  }, [activePiece, level, score, spawnPiece]);

  const spawnDiamonds = (rowIndex: number) => {
    const newDiamonds: Diamond[] = Array.from({ length: 15 }).map(() => ({
      id: Math.random().toString(36).substr(2, 9),
      x: Math.random() * COLS * 30,
      y: rowIndex * 30,
      vx: (Math.random() - 0.5) * 10,
      vy: Math.random() * 5 + 2,
      rotation: Math.random() * 360,
      scale: Math.random() * 0.5 + 0.5,
      opacity: 1,
    }));
    setDiamonds((prev) => [...prev, ...newDiamonds]);
  };

  useEffect(() => {
    if (gameOver || isPaused) return;

    const dropInterval = Math.max(100, 800 - (level - 1) * 100);
    const interval = setInterval(() => {
      move({ x: 0, y: 1 });
    }, dropInterval);

    return () => clearInterval(interval);
  }, [move, level, gameOver, isPaused]);

  // Diamond animation loop
  useEffect(() => {
    const interval = setInterval(() => {
      setDiamonds((prev) =>
        prev
          .map((d) => ({
            ...d,
            y: d.y + d.vy,
            x: d.x + d.vx,
            rotation: d.rotation + 5,
            opacity: d.opacity - 0.01,
          }))
          .filter((d) => d.opacity > 0 && d.y < ROWS * 30 + 100)
      );
    }, 16);
    return () => clearInterval(interval);
  }, []);

  const resetGame = () => {
    setGrid(Array.from({ length: ROWS }, () => Array(COLS).fill(null)));
    setActivePiece(null);
    setScore(0);
    setLevel(1);
    setGameOver(false);
    setDiamonds([]);
    spawnPiece();
  };

  useEffect(() => {
    spawnPiece();
  }, []);

  return {
    grid,
    activePiece,
    score,
    level,
    gameOver,
    diamonds,
    isPaused,
    setIsPaused,
    move,
    rotate,
    resetGame,
  };
};
